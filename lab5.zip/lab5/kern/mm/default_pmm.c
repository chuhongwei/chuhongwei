#include <pmm.h>
#include <list.h>
#include <string.h>
#include <default_pmm.h>

/*  In the First Fit algorithm, the allocator keeps a list of free blocks
 * (known as the free list). Once receiving a allocation request for memory,
 * it scans along the list for the first block that is large enough to satisfy
 * the request. If the chosen block is significantly larger than requested, it
 * is usually splitted, and the remainder will be added into the list as
 * another free block.
 *  Please refer to Page 196~198, Section 8.2 of Yan Wei Min's Chinese book
 * "Data Structure -- C programming language".
*/
// LAB2 EXERCISE 1: YOUR CODE
// you should rewrite functions: `default_init`, `default_init_memmap`,
// `default_alloc_pages`, `default_free_pages`.
/*
 * Details of FFMA
 * (1) Preparation:
 *  In order to implement the First-Fit Memory Allocation (FFMA), we should
 * manage the free memory blocks using a list. The struct `free_area_t` is used
 * for the management of free memory blocks.
 *  First, you should get familiar with the struct `list` in list.h. Struct
 * `list` is a simple doubly linked list implementation. You should know how to
 * USE `list_init`, `list_add`(`list_add_after`), `list_add_before`, `list_del`,
 * `list_next`, `list_prev`.
 *  There's a tricky method that is to transform a general `list` struct to a
 * special struct (such as struct `page`), using the following MACROs: `le2page`
 * (in memlayout.h), (and in future labs: `le2vma` (in vmm.h), `le2proc` (in
 * proc.h), etc).
 * (2) `default_init`:
 *  You can reuse the demo `default_init` function to initialize the `free_list`
 * and set `nr_free` to 0. `free_list` is used to record the free memory blocks.
 * `nr_free` is the total number of the free memory blocks.
 * (3) `default_init_memmap`:
 *  CALL GRAPH: `kern_init` --> `pmm_init` --> `page_init` --> `init_memmap` -->
 * `pmm_manager` --> `init_memmap`.
 *  This function is used to initialize a free block (with parameter `addr_base`,
 * `page_number`). In order to initialize a free block, firstly, you should
 * initialize each page (defined in memlayout.h) in this free block. This
 * procedure includes:
 *  - Setting the bit `PG_property` of `p->flags`, which means this page is
 * valid. P.S. In function `pmm_init` (in pmm.c), the bit `PG_reserved` of
 * `p->flags` is already set.
 *  - If this page is free and is not the first page of a free block,
 * `p->property` should be set to 0.
 *  - If this page is free and is the first page of a free block, `p->property`
 * should be set to be the total number of pages in the block.
 *  - `p->ref` should be 0, because now `p` is free and has no reference.
 *  After that, We can use `p->page_link` to link this page into `free_list`.
 * (e.g.: `list_add_before(&free_list, &(p->page_link));` )
 *  Finally, we should update the sum of the free memory blocks: `nr_free += n`.
 * (4) `default_alloc_pages`:
 *  Search for the first free block (block size >= n) in the free list and reszie
 * the block found, returning the address of this block as the address required by
 * `malloc`.
 *  (4.1)
 *      So you should search the free list like this:
 *          list_entry_t le = &free_list;
 *          while((le=list_next(le)) != &free_list) {
 *          ...
 *      (4.1.1)
 *          In the while loop, get the struct `page` and check if `p->property`
 *      (recording the num of free pages in this block) >= n.
 *              struct Page *p = le2page(le, page_link);
 *              if(p->property >= n){ ...
 *      (4.1.2)
 *          If we find this `p`, it means we've found a free block with its size
 *      >= n, whose first `n` pages can be malloced. Some flag bits of this page
 *      should be set as the following: `PG_reserved = 1`, `PG_property = 0`.
 *      Then, unlink the pages from `free_list`.
 *          (4.1.2.1)
 *              If `p->property > n`, we should re-calculate number of the rest
 *          pages of this free block. (e.g.: `le2page(le,page_link))->property
 *          = p->property - n;`)
 *          (4.1.3)
 *              Re-caluclate `nr_free` (number of the the rest of all free block).
 *          (4.1.4)
 *              return `p`.
 *      (4.2)
 *          If we can not find a free block with its size >=n, then return NULL.
 * (5) `default_free_pages`:
 *  re-link the pages into the free list, and may merge small free blocks into
 * the big ones.
 *  (5.1)
 *      According to the base address of the withdrawed blocks, search the free
 *  list for its correct position (with address from low to high), and insert
 *  the pages. (May use `list_next`, `le2page`, `list_add_before`)
 *  (5.2)
 *      Reset the fields of the pages, such as `p->ref` and `p->flags` (PageProperty)
 *  (5.3)
 *      Try to merge blocks at lower or higher addresses. Notice: This should
 *  change some pages' `p->property` correctly.
 */
free_area_t free_area;

#define free_list (free_area.free_list)
#define nr_free (free_area.nr_free)

static void
default_init(void) {
    list_init(&free_list);
    nr_free = 0;
}

static void
default_init_memmap(struct Page *base, size_t n) {
    int i;
    for(i = 0;i<n;i++) {
        base[i].property = 0; // 当这个页为可用且不为head, 则为0
        base[i].flags = 0; // 设置初始flag
        if(i == 0) {
            base[i].property = n; // 这个为head, 设置为页表数组的长度n
            SetPageProperty(&base[i]); // 设置head的property
        }
        set_page_ref(&base[i], 0); // p->ref为0(与注释一致)
    }
    list_add_after(&free_list, &(base->page_link)); // 与注释一致
    nr_free += n;   // 有n个页加入到可用状态中
}

static struct Page *
default_alloc_pages(size_t n) {
    if(n < 0 || n > nr_free) { // 不合法判断
        return NULL;
    }
    struct Page* ret_page = NULL; // 保存返回的页表
    list_entry_t* listnode = list_next(&free_list);
    while(listnode != &free_list) {
        struct Page* tmp = le2page(listnode, page_link);  // 通过listnode找到对应的页
        if(tmp->property >= n) { // 【贪心】找到一个页表头(first-fit),并且该页表足够用
            ret_page = tmp; // 准备返回这一页
            break;
        }
        listnode = list_next(listnode); // 没有找到, 继续寻找
    }
    if(ret_page != NULL) {
        // 成功找到,接下来要判断,如果找到的页超过了申请的大小,那么将超出的部分返回给freelist
        if(ret_page->property > n) {
            // 该页过大, 把它切分出来
            struct Page* tmp = &ret_page[n]; // 定位tmp,为切分后得到的页表的头
            tmp->property = ret_page->property - n; // 新的页表大小为ret_page->property和n的差
            ret_page->property = n; // 重设ret_page的大小为n(因为只申请了n)
            SetPageProperty(tmp); // tmp为新的页表的头
            list_add(&(ret_page->page_link), &(tmp->page_link)); // 把新的页表加到free_list中对应ret_page的后面
        }
        list_del(&ret_page->page_link); // 由于已经分配好了,所以将ret_page从free_list中删除
        nr_free -= n;   // ret_page使用了n, 剩余空间减少n
        ClearPageProperty(ret_page); // 返回的ret_page已经处于被使用状态,调用clearpageproperty宏, 将flags的对应位设置为0
    }

    return ret_page;
}

static void
default_free_pages(struct Page *base, size_t n) {
    int i = 0;
    for(i = 0;i<n;i++) { // 清空页表的所有信息
        base[i].flags = 0;
        base[i].ref = 0;
    }
    base[0].property = n; // 表明有n个空余的表项
    SetPageProperty(base); // 表明base是head

    struct Page *p;
    list_entry_t* listnode = list_next(&free_list);
    // 将相邻的空闲空间合并, 需要循环判断base的前一个空间和后一个空间能否合并(如果能够合并的话还要对合并后的大空间进行判断[因此需要循环])
    while(listnode != &free_list) { // 从free_list的下一项(内存头部)开始搜索, 将相邻的空闲内存合并
        p = le2page(listnode, page_link); // 得到此时的页表
        if(&base[base->property] == p) {  // 如果加入base后, base以及base末尾的下一个页表可以组成一个更大的空闲空间
            base->property += p->property; // 合并他们, 新的连续空间的 头部为base, 长度合并
            ClearPageProperty(p);          // p已经不再是头部(改成base了)
            list_del(&p->page_link);       // 将p从list中删除, p已经放在base的后面几位了
        } else if(&p[p->property] == base) { // 如果加入base后, base以及base的头部的上一个页表可以组成一个更大的空闲空间
            p->property += base->property;  // 合并他们,新的连续空间的 头部为p
            ClearPageProperty(base);        // base已经不再为头部了
            base = p;                       // 将要寻找的base改为p, 继续循环,判断接下来的空间能否与当前的大空间合并
            list_del(&p->page_link);        // 将base从list中删除, base已经放在p的最后面几位了
        }
        listnode = list_next(listnode);     // 继续循环
    }
    
    // 保持页表排序:
    listnode = list_next(&free_list);
    while(listnode != &free_list) {
        p = le2page(listnode, page_link);   // 找到该list对应的页
        if(&base[base->property] > p) {
            // 如果base的末尾的地址比p(listnode)的地址要大
            break; // 结束寻找
        }
        listnode = list_next(listnode);
    }
    // 把base放到listnode后面
    list_add(listnode, &base->page_link);

    nr_free += n; // 空间释放, free+=n
}

static size_t
default_nr_free_pages(void) {
    return nr_free;
}

static void
basic_check(void) {
    struct Page *p0, *p1, *p2;
    p0 = p1 = p2 = NULL;
    assert((p0 = alloc_page()) != NULL);
    assert((p1 = alloc_page()) != NULL);
    assert((p2 = alloc_page()) != NULL);

    assert(p0 != p1 && p0 != p2 && p1 != p2);
    assert(page_ref(p0) == 0 && page_ref(p1) == 0 && page_ref(p2) == 0);

    assert(page2pa(p0) < npage * PGSIZE);
    assert(page2pa(p1) < npage * PGSIZE);
    assert(page2pa(p2) < npage * PGSIZE);

    list_entry_t free_list_store = free_list;
    list_init(&free_list);
    assert(list_empty(&free_list));

    unsigned int nr_free_store = nr_free;
    nr_free = 0;

    assert(alloc_page() == NULL);

    free_page(p0);
    free_page(p1);
    free_page(p2);
    assert(nr_free == 3);

    assert((p0 = alloc_page()) != NULL);
    assert((p1 = alloc_page()) != NULL);
    assert((p2 = alloc_page()) != NULL);

    assert(alloc_page() == NULL);

    free_page(p0);
    assert(!list_empty(&free_list));

    struct Page *p;
    assert((p = alloc_page()) == p0);
    assert(alloc_page() == NULL);

    assert(nr_free == 0);
    free_list = free_list_store;
    nr_free = nr_free_store;

    free_page(p);
    free_page(p1);
    free_page(p2);
}

// LAB2: below code is used to check the first fit allocation algorithm (your EXERCISE 1) 
// NOTICE: You SHOULD NOT CHANGE basic_check, default_check functions!
static void
default_check(void) {
    int count = 0, total = 0;
    list_entry_t *le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        assert(PageProperty(p));
        count ++, total += p->property;
    }
    assert(total == nr_free_pages());

    basic_check();

    struct Page *p0 = alloc_pages(5), *p1, *p2;
    assert(p0 != NULL);
    assert(!PageProperty(p0));

    list_entry_t free_list_store = free_list;
    list_init(&free_list);
    assert(list_empty(&free_list));
    assert(alloc_page() == NULL);

    unsigned int nr_free_store = nr_free;
    nr_free = 0;

    free_pages(p0 + 2, 3);
    assert(alloc_pages(4) == NULL);
    assert(PageProperty(p0 + 2) && p0[2].property == 3);
    assert((p1 = alloc_pages(3)) != NULL);
    assert(alloc_page() == NULL);
    assert(p0 + 2 == p1);

    p2 = p0 + 1;
    free_page(p0);
    free_pages(p1, 3);
    assert(PageProperty(p0) && p0->property == 1);
    assert(PageProperty(p1) && p1->property == 3);

    assert((p0 = alloc_page()) == p2 - 1);
    free_page(p0);
    assert((p0 = alloc_pages(2)) == p2 + 1);

    free_pages(p0, 2);
    free_page(p2);

    assert((p0 = alloc_pages(5)) != NULL);
    assert(alloc_page() == NULL);

    assert(nr_free == 0);
    nr_free = nr_free_store;

    free_list = free_list_store;
    free_pages(p0, 5);

    le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        count --, total -= p->property;
    }
    assert(count == 0);
    assert(total == 0);
}

const struct pmm_manager default_pmm_manager = {
    .name = "default_pmm_manager",
    .init = default_init,
    .init_memmap = default_init_memmap,
    .alloc_pages = default_alloc_pages,
    .free_pages = default_free_pages,
    .nr_free_pages = default_nr_free_pages,
    .check = default_check,
};

